EFI for Hackintosh

using for NVIDIA GeForce GTX 650 (kelper)
Mojave 10.14.6<br/>
All lan, internet, audio...